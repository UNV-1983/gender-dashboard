/**
 * UN Lao PDR Gender Parity Dashboard — backend
 * ------------------------------------------------
 * Paste this whole file into: your Google Sheet > Extensions > Apps Script
 * Then: Deploy > New deployment > Web app > Who has access: Anyone > Deploy
 * Copy the resulting URL (ends in /exec) into the dashboard HTML file,
 * at the line marked API_URL near the top of the <script> section.
 *
 * Data lives in two tabs of THIS spreadsheet, created automatically the
 * first time the script runs: "Config" and "Staff".
 */

const SHEET_CONFIG = 'Config';
const SHEET_STAFF = 'Staff';
const STAFF_COLUMNS = ['id','agency','name','title','email','gender','contractType','contractLevel','addedBy','addedAt'];

function doGet(e) { return handle(e); }
function doPost(e) { return handle(e); }

function handle(e) {
  let result;
  try {
    const p = e.parameter || {};
    const action = p.action;
    ensureSheets();
    if (action === 'getConfig') result = getConfig();
    else if (action === 'saveConfig') result = saveConfig(JSON.parse(p.payload));
    else if (action === 'getStaff') result = getStaff();
    else if (action === 'saveStaff') result = saveStaffAll(JSON.parse(p.payload));
    else result = { error: 'Unknown action: ' + action };
  } catch (err) {
    result = { error: String(err) };
  }
  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }

function ensureSheets() {
  const ss = ss_();
  let cfg = ss.getSheetByName(SHEET_CONFIG);
  if (!cfg) {
    cfg = ss.insertSheet(SHEET_CONFIG);
    cfg.getRange(1, 1, 1, 2).setValues([['key', 'value']]);
  }
  let staff = ss.getSheetByName(SHEET_STAFF);
  if (!staff) {
    staff = ss.insertSheet(SHEET_STAFF);
    staff.getRange(1, 1, 1, STAFF_COLUMNS.length).setValues([STAFF_COLUMNS]);
  }
}

/* ---------------- Config (host, editors, mode, deadline, logos) ---------------- */

function getConfig() {
  const sh = ss_().getSheetByName(SHEET_CONFIG);
  const rows = sh.getDataRange().getValues();
  const map = {};
  for (let i = 1; i < rows.length; i++) {
    const [key, value] = rows[i];
    if (key) map[key] = value;
  }
  if (!map.hostEmail) return null; // no host claimed yet
  return {
    hostEmail: map.hostEmail || '',
    hostName: map.hostName || '',
    editors: map.editors ? JSON.parse(map.editors) : [],
    mode: map.mode || 'internal',
    deadline: map.deadline || null,
    logos: map.logos ? JSON.parse(map.logos) : {}
  };
}

function saveConfig(cfg) {
  const sh = ss_().getSheetByName(SHEET_CONFIG);
  const rows = [
    ['key', 'value'],
    ['hostEmail', cfg.hostEmail || ''],
    ['hostName', cfg.hostName || ''],
    ['editors', JSON.stringify(cfg.editors || [])],
    ['mode', cfg.mode || 'internal'],
    ['deadline', cfg.deadline || ''],
    ['logos', JSON.stringify(cfg.logos || {})]
  ];
  sh.clearContents();
  sh.getRange(1, 1, rows.length, 2).setValues(rows);
  return { ok: true };
}

/* ---------------- Staff records ---------------- */

function getStaff() {
  const sh = ss_().getSheetByName(SHEET_STAFF);
  const rows = sh.getDataRange().getValues();
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    if (!rows[i][0]) continue; // skip blank rows
    const rec = {};
    STAFF_COLUMNS.forEach((col, idx) => { rec[col] = rows[i][idx]; });
    out.push(rec);
  }
  return out;
}

// Full replace — the dashboard sends the complete staff list on every add/edit/delete.
function saveStaffAll(list) {
  const sh = ss_().getSheetByName(SHEET_STAFF);
  sh.clearContents();
  sh.getRange(1, 1, 1, STAFF_COLUMNS.length).setValues([STAFF_COLUMNS]);
  if (list.length) {
    const rows = list.map(rec => STAFF_COLUMNS.map(col => rec[col] !== undefined ? rec[col] : ''));
    sh.getRange(2, 1, rows.length, STAFF_COLUMNS.length).setValues(rows);
  }
  return { ok: true };
}
